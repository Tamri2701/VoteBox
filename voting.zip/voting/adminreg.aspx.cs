﻿using System;


namespace voting
{
    public partial class adminreg : System.Web.UI.Page
    {
     


            protected void Page_Load(object sender, EventArgs e)
            {
                if (!IsPostBack)
                {
                purchasePlanPopup.Visible = false;

                }
           
        }
        protected DateTime votingDate;
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
    

            string adminName = txtAdminName.Text;
      
            DateTime votingDate = this.votingDate;

           
            string message = $"Admin Name: {adminName} Date of Voting Day: {votingDate.ToShortDateString()}";
            ClientScript.RegisterStartupScript(this.GetType(), "alert", $"alert('{message}');", true);
        }
        protected void rbLayout_CheckedChanged(object sender, EventArgs e)
        {
            if (rbMultiPosition.Checked)
            {
                purchasePlanPopup.Visible = true;
            }
            else
            {
                purchasePlanPopup.Visible = false;
            }
        }

     
        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
            {
                // Update the text box with the selected date
                txtDate.Text = Calendar1.SelectedDate.ToShortDateString();
                votingDate = Calendar1.SelectedDate;


            // Hide the calendar after selection
            Calendar1.Visible = false; 
            }
      

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("subscription.aspx");
        }
    }
        
    }
    

