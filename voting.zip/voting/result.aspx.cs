﻿using iText.Kernel.Pdf;
using iText.Layout;
using iText.Html2pdf;

using System.IO;
using System.Web.UI;
using System.Web;
using System;


namespace voting
{
    public partial class result : System.Web.UI.Page
    {

        protected void btnGeneratePDF_Click(object sender, EventArgs e)
        {
            Response.ContentType = "application/pdf";
            Response.AddHeader("content-disposition", "attachment;filename=ChartPDF.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);

            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            Page.RenderControl(hw);

            string htmlContent = sw.ToString(); // Get HTML content as string

            MemoryStream msOutput = new MemoryStream();

            // Use HtmlConverter to convert HTML to PDF
            HtmlConverter.ConvertToPdf(htmlContent, msOutput);

            msOutput.WriteTo(Response.OutputStream);
            msOutput.Close();

            Response.End();
        }
       
    }
}



            // Create a new MemoryStream to hold the PDF file content



