﻿using System;
using System.Configuration;
using System.Web.UI;

using System.Data.SqlClient;

namespace voting
{
    public partial class userform : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                BindGridView();

                string startTime = Request.Cookies["StartTime"]?.Value;
                string endTime = Request.Cookies["EndTime"]?.Value;

                if (!string.IsNullOrEmpty(startTime) && !string.IsNullOrEmpty(endTime))
                {
                    // Display the start and end times on the userform page
                    lblStartTime.Text = startTime;
                    lblEndTime.Text = endTime;

                    // Check if the current time is within the voting period and display remaining time if necessary
                    DateTime startDateTime = DateTime.Parse(startTime);
                    DateTime endDateTime = DateTime.Parse(endTime);
                    if (DateTime.Now > endDateTime)
                    {
                        ScriptManager.RegisterStartupScript(this, GetType(), "TimeUpAlert", "alert('Voting time is up. You cannot cast your vote.');", true);
                    }
                    else
                    {
                        TimeSpan remainingTime = endDateTime - DateTime.Now;
                        string remainingTimeString = $"{remainingTime.TotalHours:N0} hours and {remainingTime.Minutes} minutes left to vote.";
                        lblRemainingTime.Text = remainingTimeString;
                    }
                }
                else
                {
                    lblErrorMessage.Text = "Start time or end time not found in cookies.";
                }
            }


        }



        // Check if the session variables exist and are not null



        private void BindGridView()
        {
           
            GridView1.DataBind();
        }
      

        protected void GridView1_RowCommand(object sender, System.Web.UI.WebControls.GridViewCommandEventArgs e)
        {
            if (e.CommandName == "VoteClick")
            {
                int rowIndex = Convert.ToInt32(e.CommandArgument);
                UpdateVote(rowIndex);
                BindGridView(); 
            }
        }

        private void UpdateVote(int rowIndex)
        {
            using (SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["voteadminConnectionString3"].ConnectionString))
            {
                con.Open();

                // Retrieve the current vote count for the person
                int currentVoteCount;
                using (SqlCommand cmd = new SqlCommand("SELECT VoteCount FROM Votes WHERE VoteID = @VoteID", con))
                {
                    cmd.Parameters.AddWithValue("@VoteID", GridView1.DataKeys[rowIndex].Value);
                    currentVoteCount = Convert.ToInt32(cmd.ExecuteScalar());
                }

                // Increment the vote count
                int newVoteCount = currentVoteCount + 1;

                // Update the vote count in the database
                using (SqlCommand cmd = new SqlCommand("UPDATE Votes SET VoteCount = @VoteCount WHERE VoteID = @VoteID", con))
                {
                    cmd.Parameters.AddWithValue("@VoteCount", newVoteCount);
                    cmd.Parameters.AddWithValue("@VoteID", GridView1.DataKeys[rowIndex].Value);
                    cmd.ExecuteNonQuery();
                }

                // Display the vote message
                string votedPersonName = GridView1.Rows[rowIndex].Cells[1].Text;
                lblVoteMessage.Text = $"You have voted for {votedPersonName}. Total votes: {newVoteCount}.";
                lblVoteMessage.Visible = true;
            }
        }


        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

       
    }


